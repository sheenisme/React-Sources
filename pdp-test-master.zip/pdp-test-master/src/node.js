var http = require("http");
var url = require("url");
var mysql = require('mysql');
var querystring = require('querystring');
const express = require('express')
const Router = express.Router()


var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'goods'
});
connection.connect();

var find = () => new Promise(resolve => {
  connection.query('SELECT * from todolist', function (error, results, fields) {
    if (error) throw error;
    resolve(results);
  });
})
//delete是关键字
var delete1 = (id) => new Promise(resolve => {
  connection.query('delete from TodoList where id = ?', [id], function (error, results, fields) {
    if (error) throw error;
    resolve(results);
  });
})
var add1 = (title) => new Promise(resolve => {
  connection.query('INSERT INTO TodoList(title) VALUES(?)', [title], function (error, results, fields) {
    if (error) throw error;
    resolve(results);
  });
})
var update1 = (title, completed, bol, id) => new Promise(resolve => {
  connection.query('update TodoList set title=?,completed=?,bol=? where id=?', [title, completed, bol, id], function (error, results, fields) {
    if (error) throw error;
    resolve(results);
  });
})


var httpServer = http.createServer(
  function (req, res) {
    if (req.url == "/favicon.ico") { return; }//假如访问的路径是网站图片

    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf8', 'Access-Control-Allow-Origin': "*" });
    let urlString = req.url;
    let url1 = url.parse(urlString, true);
    console.log(url1);
    let loginName = url1.pathname;
    // res.end(loginName);

    if (loginName == '/find') {
      find().then(
        value => {
          res.end(JSON.stringify(value));
        })
    }//find
    else if (loginName == '/delete') {
      // console.log("delete")
      // console.log(url1.query.id);
      let id = url1.query.id;
      delete1(id).then(
        value => {
          res.end(value + "");
        })
    }//delete
    else if (loginName == '/add') {
      let title = url1.query.title;
      add1(title).then(
        value => {
          res.end(value + "");
        })
    }//add
    else if (loginName == '/update') {
      let title = url1.query.title;
      let completed = url1.query.completed;
      let bol = url1.query.bol;
      let id = url1.query.id;
      if (completed === 0) {
        completed = false;
      } else {
        completed = true;
      }
      if (bol === 0) {
        bol = false;
      } else {
        bol = true;
      }
      console.log(title + completed + bol + id)
      update1(title, completed, bol, id).then(
        value => {
          res.end(value + "");
        })
    }


    let userName = url1.query.userName;
    let pass = url1.query.pass;

  });

httpServer.listen(8080, "192.168.1.104");
